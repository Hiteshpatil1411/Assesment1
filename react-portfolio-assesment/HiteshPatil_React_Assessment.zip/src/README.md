o Project title
    React Portfolio Assesment

o Name: Hitesh Sanjay Patil

o Steps to run the project
    cd react-portfolio-assesment
    npm start
o Technologies used
    HTLM
    CSS
    JS
    ReactJS
