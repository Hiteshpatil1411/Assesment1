function Footer(){
    return(

        <>
        <div className="footer mt-3 p-2 bg-light-subtle d-flex align-items-center justify-content-center" id="footer">
            

            <p className="text-center text-secondary">Copyright ©2025 All rights reserved | This template is made with  by Hitesh Patil</p>
        </div>
        
        </>
    )
}
export default Footer;