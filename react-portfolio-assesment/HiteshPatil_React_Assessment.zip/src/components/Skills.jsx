function Skills(){
    return(
        <>


        <div className="skill mb-3"  id="skill">

            <div className="card text-center mb-3" style={{width:"450px" , margin:"auto"}}>
  <div className="card-body">
    <h5 className="card-title text-start fs-4">Skills</h5>
    <div className="card-text d-flex justify-content-evenly mt-3">
        <div className="badge text-bg-success">ReactJS</div>
        <div className="badge text-bg-success">Java Script</div>
        <div className="badge text-bg-success">Bootstrap</div>
        <div className="badge text-bg-success">Java</div>
        <div className="badge text-bg-success">Python</div>
    </div>
    
  </div>
</div>

        </div>
        
        
        </>
    )


}
export default Skills;